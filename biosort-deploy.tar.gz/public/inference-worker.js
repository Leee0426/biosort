// public/inference-worker.js
importScripts('https://cdn.jsdelivr.net/npm/inferencejs@latest/+esm');

// This file enables Web Workers for Inference.js
// It should be served from your public directory